#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

#define False 0
#define True  1
#define MAX_NUMBER 1000

char** create_map();
void print_map();

void setup_village();
void setup_monster();
void setup_player();

int check_boundary();
int check_availability();

void go_up();
void go_down();
void go_left();
void go_right();
int check_move();

int main(void){
    //Map's data & ptr
    int mapRow = MAX_NUMBER;
    int mapcol = MAX_NUMBER;
    int *ptr_mapRow = &mapRow;
    int *ptr_mapcol = &mapcol;
    //Player's position
    int Prow = 0;
    int Pcol = 0;
    int *ptr_Prow = &Prow;
    int *ptr_Pcol = &Pcol;
    int choice;

    char **map = create_map(ptr_mapRow,ptr_mapcol);
    setup_village(map, ptr_mapRow,ptr_mapcol);
    setup_monster(map, ptr_mapRow, ptr_mapcol);
    print_map(map,ptr_mapRow,ptr_mapcol);

    //是否重建地圖?
    printf("[1] Create a new map [2] Start travel the map: ");
    scanf("%d", &choice);
    while(choice == 1){
        map = create_map(ptr_mapRow,ptr_mapcol);
        setup_village(map, ptr_mapRow,ptr_mapcol);
        setup_monster(map, ptr_mapRow, ptr_mapcol);
        print_map(map,ptr_mapRow,ptr_mapcol);
        printf("[1] Create a new map [2] Start travel the map: ");
        scanf("%d", &choice);
        if(choice==2)
            break;
    }

    //玩家區塊
    setup_player(map, ptr_mapRow, ptr_mapcol,ptr_Prow,ptr_Pcol);
    print_map(map,ptr_mapRow,ptr_mapcol);
    while(1){
        printf("[w] go up [s] go down [d] go right [a] go left [q] exit:");
        char move;
        char flush;
        scanf("%c", &flush);
        scanf("%c", &move);
        printf("r = %d", flush);
        switch(move){
            case 'w':
                go_up(map,ptr_Prow,ptr_Pcol,ptr_mapRow,ptr_mapcol);
                break;
            case 's':
                go_down(map,ptr_Prow,ptr_Pcol,ptr_mapRow,ptr_mapcol);
                break;
            case 'd':
                go_right(map,ptr_Prow,ptr_Pcol,ptr_mapRow,ptr_mapcol);
                break;
            case 'a':
                go_left(map,ptr_Prow,ptr_Pcol,ptr_mapRow,ptr_mapcol);
                break;
        }
        if(move=='q'){
            printf("Bye!");
            break;
        }
    }

    system("pause");
    return 0;
}

char** create_map(int *row,int *col){
    printf("Input the number of row and column for the map:\n");
    scanf("%d %d", row, col);
    char **map = (char**) malloc(*row * sizeof(char *)); //替字元指標分配記憶體
    for(int i = 0; i < *row; i++)
        map[i] = (char*) malloc((*col) * sizeof(char));

    for (int i = 0; i < *row; i++)
        for (int j = 0; j < *col; j++)
            map[i][j] = '.'; 


    return map;
}

void print_map(char **map,int *row,int *col){
    printf("=== MAP ===\n");
    for (int i = 0; i <  *row ; i++){
        for (int j = 0; j < *col; j++){
            printf("%c ", map[i][j]);
        }
        printf("\n");
    }
    printf("=== MAP ===\n");

}

void setup_village(char **map,int *row,int *col){
    int village_num = (*row / 10) + (*col % 10) - 2;
    int Vrow ,Vcol;
    printf("You need to assign location for %d villages in total\n",village_num);
    for (int i = 1; i <= village_num;i++){
        printf("Input the row and column for the village[%d] location:\n",i);
        scanf("%d %d", &Vrow, &Vcol);
        //Range check
        if(!(check_boundary(Vrow, Vcol,row,col))){     
            i--;
        }
        //Occupied cheack
        else if(!(check_availability(map,Vrow, Vcol)))
            i--;
        else
            map[Vrow][Vcol] = 'v';
    }
}

void setup_monster(char **map,int *row,int *col){
    int monster_num = (*row / 10) + (*col % 10) - 1;
    int Mrow ,Mcol;
    printf("You need to assign location for %d monsters in total\n",monster_num);
    for (int i = 1; i <= monster_num; i++){
        printf("Input the row and column for monster[%d]:\n", i);
        scanf("%d %d", &Mrow, &Mcol);

        //Range check
        if(!(check_boundary(Mrow, Mcol,row,col))){     
            i--;
        }
        //Occupied cheack
        else if(!(check_availability(map,Mrow, Mcol)))
            i--;
        else
            map[Mrow][Mcol] = 'm';
    }
}

void setup_player(char **map,int *row,int *col,int *Prow,int *Pcol){
    printf("Input the row and column for player:\n");
    scanf("%d %d", Prow, Pcol);
    int isValid = False;
    while(isValid == False){
        if(check_boundary(*Prow, *Pcol,*row,*col)== False || check_availability(map,*Prow, *Pcol) == False){
            printf("Input the new row and column for player:\n");
            scanf("%d %d", Prow, Pcol);
        }
        else
            isValid = True;
    }
    map[*Prow][*Pcol] = 'p';
}

//判斷是否超出地圖範圍
int check_boundary(int check_row,int check_col,int row,int col){
    //超出範圍，回傳0
    if(check_row > ((row) - 1) || check_col > ((col) - 1) || check_row < 0 || check_col < 0){
        printf("the location is outside the map\n");
        return False;
    }
    else
        return True;
}

//判斷是否已經被佔領過，已佔領過回傳False
int check_availability(char **map,int check_row,int check_col){
    if(map[check_row][check_col] == 'm' || map[check_row][check_col] == 'v'){
        printf("the location is occupied\n");
        return False;
    }
    else
        return True;   
}

void go_up(char **map,int *Prow,int *Pcol,int *row,int *col){
    map[*Prow][*Pcol] = '.';
    (*Prow)--;
    if(check_move(map,Prow,Pcol,row,col)==False){
        (*Prow)++;
    }
    map[*Prow][*Pcol] = 'p';
    print_map(map,row,col);
}
void go_down(char **map,int *Prow,int *Pcol,int *row,int *col){
    map[*Prow][*Pcol] = '.';
    (*Prow)++;
    if(check_move(map,Prow,Pcol,row,col)==False){
        (*Prow)--;
    }
    map[*Prow][*Pcol] = 'p';
    print_map(map,row,col);

}
void go_left(char **map,int *Prow,int *Pcol,int *row,int *col){
    map[*Prow][*Pcol] = '.';
    (*Pcol)--;
    if(check_move(map,Prow,Pcol,row,col)==False){
        (*Pcol)++;
    }
    map[*Prow][*Pcol] = 'p';
    print_map(map,row,col);
}
void go_right(char **map,int *Prow,int *Pcol,int *row,int *col){
    map[*Prow][*Pcol] = '.';
    (*Pcol)++;
    if(check_move(map,Prow,Pcol,row,col)==False){
        (*Pcol)--;
    }
    map[*Prow][*Pcol] = 'p';
    print_map(map,row,col);
}

//丟入地圖、玩家位址、地圖的行列，用以判斷目前玩家移動軌跡是否合法
int check_move(char **map,int *Prow,int *Pcol,int *row,int *col){
    if(*Prow > (*row - 1) || *Pcol > (*col - 1) || *Prow < 0 || *Pcol < 0){
        printf("You can't go there\n");
        return False;
    }
    if(map[*Prow][*Pcol] == 'm' || map[*Prow][*Pcol] == 'v'){
        printf("You can't go there\n");
        return False;
    }
    return True;
}